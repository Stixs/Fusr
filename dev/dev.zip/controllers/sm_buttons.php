<div class="col-xs-2 facebook">
	<div class="fb-like" data-layout="button_count" data-action="like" data-show-faces="false" data-share="true"></div>
</div>
<div class="col-xs-2 pinterest">
	<a data-pin-do="buttonBookmark" null href="//www.pinterest.com/pin/create/button/"><img src="//assets.pinterest.com/images/pidgets/pinit_fg_en_rect_gray_20.png" /></a>
	<!-- Please call pinit.js only once per page -->
	<script async defer src="//assets.pinterest.com/js/pinit.js"></script>
</div>
<div class="col-xs-2 twitter">
	<a href="https://twitter.com/share" class="twitter-share-button" >Tweet</a>
</div>
<div class="col-xs-2 googleplus">
	<div class="g-plusone" data-annotation="none" data-size="tall" ... ></div>
</div>
<div class="col-xs-2 linkedin">
	<script src="//platform.linkedin.com/in.js" type="text/javascript"> lang: en_US</script>
<script type="IN/Share" data-counter="right"></script>
</div>
<div class="col-xs-2 instagram">
	<span class="ig-follow" data-id="5479dee" data-handle="igfbdotcom" data-count="true" data-size="large" data-username="true"></span>
</div>