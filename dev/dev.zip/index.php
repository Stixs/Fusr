<?php
require('./controllers/header.php');
?>

<div class="row">
<div class="col-xs-12 advert">
  


<?php
require('./controllers/footer.php');
?>
