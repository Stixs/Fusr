<?php

$x = 'cd';

${'ab'.$x} = 'hello';


echo $abcd;

?>